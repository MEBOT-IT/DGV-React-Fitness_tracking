import React from "react";
import './SkillsBar.css'

function SkillsBar() {
    return (
        <div className="con">
        <div className="container1">
            <h1 className="title-text1">React Progress Bar</h1>

            <div className="skill-box1">
                <span className="title1">Calories Burned</span>
                <div className="skill-bar1">
                    <span className="skill-per html1">
                        <span className="tooltip">95%</span>
                    </span>
                </div>
            </div>
            <div className="skill-box1">
                <span className="title1">Cardio</span>
                <div className="skill-bar1">
                    <span className="skill-per css1">
                        <span className="tooltip1">80%</span>
                    </span>
                </div>
            </div>
            <div className="skill-box1">
                <span className="title1">Strength Training</span>
                <div className="skill-bar1">
                    <span className="skill-per javascript1">
                        <span className="tooltip1">60%</span>
                    </span>
                </div>
            </div>
            <div className="skill-box1">
                <span className="title1">Weight loss Progress</span>
                <div className="skill-bar1">
                    <span className="skill-per reactjs1">
                        <span className="tooltip1">70%</span>
                    </span>
                </div>
            </div>
            <div className="skill-box1">
                <span className="title1">Today Goal Achieved</span>
                <div className="skill-bar1">
                    <span className="skill-per nodejs1">
                        <span className="tooltip1">40%</span>
                    </span>
                </div>
            </div>
            <div className="skill-box1">
                <span className="title1">Overall Fitness</span>
                <div className="skill-bar1">
                    <span className="skill-per expressjs1">
                        <span className="tooltip1">75%</span>
                    </span>
                </div>
            </div>
        </div>


    </div>
    )
}

export default SkillsBar;