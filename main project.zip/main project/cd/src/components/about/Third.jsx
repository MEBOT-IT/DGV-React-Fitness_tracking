import styles from "./about.module.css";
import photo2 from "../../assets/about5.png";

const Third = () => {
  return (
    <div
      className={`${styles.third} container sections-padding`}
      data-aos="fade-right">
      <div className={styles.third_one}>
        <div className={styles.one_content}>
          <p className="paragraph">Welcome</p>
          <h2>
            The Story Behind
            <br />
            Our Gym
          </h2>
          <p>
          We invite you to be a part of our ongoing journey. Whether you're a seasoned athlete or taking your first steps towards a healthier lifestyle, IRONJUNGLE is here to support you every step of the way.
          </p>
        </div>
        <div className={styles.one_content2}>
          <h3>Story</h3>
          <p>Our proudest moments are the transformations we witness every day—the weight loss milestones, the strength gains, the confidence boost, and the friendships formed. Each success story is a testament to the hard work and determination of our members and the guidance of our dedicated team.
          </p>
          <img src={photo2} alt="" />
        </div>
      </div>
      <div className={styles.third_two}>
        <div className={styles.two_content}>
          <h3>Our Mission</h3>
          <p>From day one, our mission has been clear—to empower, inspire, and motivate people to lead healthier, more fulfilling lives. We set out to create a space where fitness is not just a routine but a lifestyle, where goals are not just set but exceeded, and where our members become part of a fitness family.
          </p>
        </div>
        <div className={styles.two_content2}>
          <h3>Our Value</h3>
          <p>Over the years, we've grown, expanded, and adapted to meet the changing needs of our members. We've added state-of-the-art equipment, introduced innovative classes and programs, and brought in experienced trainers and instructors dedicated to helping you reach your goals.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Third;
