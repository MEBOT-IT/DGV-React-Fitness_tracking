import First from "./First";
import Second from "./Second";

const Blog = () => {
  return (
    <div>
      <First />
      <Second />
    </div>
  );
};

export default Blog;
