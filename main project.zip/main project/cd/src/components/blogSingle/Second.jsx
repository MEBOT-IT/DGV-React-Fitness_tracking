import styles from "./blogSimgle.module.css";

const Second = () => {
  return (
    <div className={styles.second}>
      <p>
        Dynamically target high pay of intellectual capital customized
        technologies objectively integrateemerging core competencies before
        process centric communities dramatically evisculate holistic innovation
        rather Progressively maintained extensived infomediaries via extensible
        dramatically disseminates standardized metrics after objectively pursue
        diverse catalysts for change for interoperable meta-services.
      </p>
      <h2>The 10 best exercises to do in your park</h2>
      <p>
        Dynamically target high pay of intellectual capital customized
        technologies objectively integrateemerging core competencies before
        process centric communities dramatically evisculate holistic innovation
        rather Progressively maintained extensived infomediaries via extensible
        dramatically disseminates standardized metrics after objectively pursue
        diverse catalysts for change for interoperable meta-services.
      </p>
      <ul>
        <li>
          Dynamically target high-payoff intellectual capital for customized
        </li>
        <li>Interactively procrastinate high-payoff content</li>
        <li>
          Credibly reinter mediate backend ideas for cross-platform models
        </li>
      </ul>

      <div className={styles.spicial}>
        <p>
          When an unknown printegalley of type and scrambled it to make a type
          specimen book. It has survived not only five centuries, but also the
          leap into electronic typesetting.
        </p>
      </div>
      <h3>The 3 steps for morning routines</h3>
      <p>
        Quickly aggregates users and the worldwides potentialities Progressively
        plagiarized a resourced leveling commerce through resource leveling core
        competencies ramatically mesh low-risk high-yield alignments before
        transparent e-tailers.
      </p>
      <ul>
        <li>
          It brings the right people together with all the right information and
          tools to get work done
        </li>
        <li>
          We provide operational efficiency, data security, and flexible scale
        </li>
        <li>
          Your best work, together in one package that works seamlessly from
          your computer
        </li>
      </ul>
    </div>
  );
};

export default Second;
