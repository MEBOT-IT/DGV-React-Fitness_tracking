import { useState } from "react";
import styles from "./calculator.module.css";
import photo1 from "../../assets/bmi chart.jpg";


export default function Second() {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmiResult, setBmiResult] = useState(null);
  const [status, setStatus] = useState("");

  function calculateBMI() {
    let bmi = Number(weight / (height / 100) ** 2).toFixed(2);
    setBmiResult(bmi);

    let bmiStatus = getStatus(bmi);

    setStatus(bmiStatus);

    setHeight("");
    setWeight("");
  }

  function getStatus(bmi) {
    if (bmi < 18.5) return "Underweight";
    else if (bmi >= 18.5 && bmi < 24.9) return "Normal";
    else if (bmi >= 25 && bmi < 29.9) return "Overweight";
    else if (bmi >= 30 && bmi < 34.9) return "Obesity Class 1";
    else if (bmi >= 35 && bmi < 39.9) return "Obesity Class 2";
    else return "Obesity Class 3";
  }
  // ... (your existing state and functions)

  return (
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <div style={{ maxWidth: "600px", margin: "0 auto", padding: "20px" }}>
        <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          {
             <div style={{ maxWidth: "600px", margin: "0 auto", padding: "20px" }}>
             <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
               <h1
                 style={{
                   textAlign: "left",
                   marginBottom: "30px",
                   fontSize: "54px",
                 }}
               >
                 BMI Calculator
               </h1><br/>
               <div className="mb-4">
                 {/* Add the image here */}
                 
                 <label
                 
                   htmlFor="Height"
                   className="block text-gray-700 text-sm font-bold mb-2"
                   style={{ fontSize: "36px",fontstyle:"bold" }}
                 >
                  <b> Height  : </b>
                 </label>
                 <input
                   id="Height"
                   type="text"
                   placeholder="Height in cm"
                   value={height}
                   onChange={(e) => setHeight(e.target.value)}
                   className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                   style={{ height: "30px" }}       
         />
               </div>
               <div className="mb-6">
                 <label
                   htmlFor="Weight"
                   className="block text-gray-700 text-sm font-bold mb-2"
                   style={{ fontSize: "36px",marginBottom: "50px"  }}
                 ><br></br>
                  <b> Weight  : </b>
                 </label>
                 <input
                   id="Weight"
                   type="text"
                   placeholder="Weight in kg"
                   value={weight}
                   onChange={(e) => setWeight(e.target.value)}
                   className="shadow appearance-none rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                   style={{ height: "30px",placeholder: { fontSize: '36px' }  }} 
                  
                   />
               </div><br/>
               <div className="flex items-center justify-center"><br></br>
                 <button
                   type="button"
                   onClick={calculateBMI}
                   className="bg-purple-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                  
                   style={{ height: "50px" }} >
                  <b style={{ fontSize: "26px" ,backgroundcolor:"red"}}>Calculate BMI</b>
                 </button>
               </div>
               {bmiResult && (
                 <div className="mt-4">
                   <p>Your BMI is: {bmiResult} </p>
                   <p>You are currently: {status}</p>
                 </div>
               )}
             </form>
               
           </div>
          }
        </form>
      </div>
      <div>
        <img src={photo1} alt="women in gym" />
      </div>
    </div>
  );
}
