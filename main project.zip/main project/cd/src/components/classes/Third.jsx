import { useNavigate } from "react-router";
import styles from "./classes.module.css";

const Third = () => {
  const navigate = useNavigate();

  return (
    <div className={styles.third} data-aos="zoom-in">
      <div>
        <h2>Join Our Club</h2>
        <p>
          
"Unleash Your Strength at Iron Jungle Fitness Gym – Where Your Goals Become Gains!"
        </p>
        <button onClick={() => navigate("/schedule")}>Start Now</button>
      </div>
    </div>
  );
};

export default Third;
