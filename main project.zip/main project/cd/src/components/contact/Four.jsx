import { useState } from "react";
import styles from "./contact.module.css";

const Four = () => {
  const [active, setActive] = useState(Array(4).fill(false));
  const [activeIndex, setActiveIndex] = useState(-1);

  const paragraphHandler = (index) => {
    setActive((prevState) => {
      const newState = [...prevState];
      newState[index] = !newState[index];
      return newState;
    });

    setActiveIndex((prevIndex) => (prevIndex === index ? -1 : index));
  };

  return (
    <div className={`${styles.four} sections-padding`}>
      <div>
        <div>
          <h4>What is the Fitnessfit schedule?</h4>
          <i
            className={`fa-solid fa-chevron-down ${
              activeIndex === 0 ? styles.activeIcon : ""
            }`}
            onClick={() => paragraphHandler(0)}></i>
        </div>
        <p className={active[0] ? styles.active : ""}>
        Schedules for fitness programs or gyms can vary widely depending on the location, type of classes offered, and the specific fitness center's operating hours.
        </p>
      </div>
      <div>
        <div>
          <h4>What's the best time to work out at the gym?</h4>
          <i
            className={`fa-solid fa-chevron-down ${
              activeIndex === 1 ? styles.activeIcon : ""
            }`}
            onClick={() => paragraphHandler(1)}></i>
        </div>
        <p className={active[1] ? styles.active : ""}> It depends on your schedule and when you feel most energized.
        </p>
      </div>

      <div>
        <div>
          <h4> How long should my gym workouts last?</h4>
          <i
            className={`fa-solid fa-chevron-down ${
              activeIndex === 2 ? styles.activeIcon : ""
            }`}
            onClick={() => paragraphHandler(2)}></i>
        </div>
        <p className={active[2] ? styles.active : ""}>Aim for 45 minutes to an hour for effective sessions.
        </p>
      </div>

      <div>
        <div>
          <h4>What's the role of hydration in fitness?</h4>
          <i
            className={`fa-solid fa-chevron-down ${
              activeIndex === 3 ? styles.activeIcon : ""
            }`}
            onClick={() => paragraphHandler(3)}></i>
        </div>
        <p className={active[3] ? styles.active : ""}>Staying hydrated is crucial for peak performance.</p>
      </div>
    </div>
  );
};

export default Four;
