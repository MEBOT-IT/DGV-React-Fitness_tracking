import styles from "./contact.module.css";

const Third = () => {
  return (
    <div className={`${styles.third}  sections-padding`} data-aos="zoom-in">
      <div className={`${styles.third_content} container`}>
        <div>
          <i className="fa-solid fa-phone"></i>
          <h4>Phone</h4>
          <p>Call us:</p>
          <p>+91 9876543210</p>
        </div>
        <div>
          <i className="fa-solid fa-envelope"></i>
          <h4>Email</h4>
          <p>Contact us with mail </p>
          <p>ironjungle777@gmail.com </p>
        </div>
        <div>
          <i className="fa-solid fa-location-dot"></i>
          <h4>Location</h4>
          <p>Our Studio located here</p>
          <p>Chennai,Tamilnadu</p>
        </div>
      </div>
    </div>
  );
};

export default Third;
