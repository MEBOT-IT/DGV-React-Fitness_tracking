import First from "./First";
import Second from "./Second";

const ErrorPage = () => {
  return (
    <div>
      <First />
      <Second />
    </div>
  );
};

export default ErrorPage;
