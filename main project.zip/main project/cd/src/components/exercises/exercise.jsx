import styles from "./exercise.module.css";

import p1 from "../../assets/1.jpg";
import p2 from "../../assets/2.jpg";
import p3 from "../../assets/3.jpg";
import p4 from "../../assets/4.jpg";
import p5 from "../../assets/5.jpg";
import p6 from "../../assets/6.jpg";

import { Link } from "react-router-dom";

const Second = () => {
  return (
    <div className={`${styles.second} container sections-padding`}>
      <div className={styles.second_text}>
        <p className="paragraph"></p>
        <h2>We Trained You to Gain</h2>
      </div>
      <div className={styles.classes}>
        <div data-aos="fade-right">
          <img src={p1} alt="" />
          <h3>Workouts For Men</h3>
          <a href="https://www.youtube.com/watch?v=AzV3EA-1-yM" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
        <div data-aos="fade-right">
          <img src={p2} alt="" />
          <h3>Workouts For Women</h3>
          <a href="https://www.youtube.com/watch?v=PG2f3GF5RlI" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
        <div data-aos="fade-right">
          <img src={p3} alt="" />
          <h3>Fat Loss</h3>
        
          <a href="https://www.youtube.com/watch?v=b7YoGQuXYRE" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
        <div data-aos="fade-right">
          <img src={p4} alt="" />
          <h3>Increase Strength</h3>
          <a href="https://www.youtube.com/watch?v=o2WR9VBvLvk" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
        <div data-aos="fade-right">
          <img src={p5} alt="" />
          <h3>Ab Workouts</h3>
          <a href="https://www.youtube.com/watch?v=3oeimlA6s68" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
        <div data-aos="fade-right">
          <img src={p6} alt="" />
          <h3>Full Body</h3>
          <a href="https://www.youtube.com/watch?v=-hSma-BRzoo" target="_blank" rel="noopener noreferrer">
            Click Here
          </a>
        </div>
      </div>
    </div>
  );
};

export default Second;
