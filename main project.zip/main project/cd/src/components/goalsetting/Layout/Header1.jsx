import React from "react";
import classes from './Header1.module.css'

const Header1 = (props) => {
  return (
    <React.Fragment>
      <header className={classes.header}>
        <h1>Daily Goals</h1>        
      </header>
      <div className={classes['main-image']}>
        <img src={""} alt="A table full of delicious food" />
      </div>
    </React.Fragment>
  );
};

export default Header1;
