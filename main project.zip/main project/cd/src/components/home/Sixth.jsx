import styles from "./home.module.css";
import photo1 from "../../assets/photo1.jpg";
import photo2 from "../../assets/photo2.jpg";
import photo4 from "../../assets/photo4.jpeg"
import photo3 from "../../assets/quet.png";
import photo5 from "../../assets/photo5.jpg";


// import Swiper
import { Navigation, Pagination, Scrollbar, A11y } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";

const Sixth = () => {
  return (
    <div
      className={`${styles.six} sections-padding`}
      data-aos="fade-up"
      data-aos-anchor-placement="center-bottom">
      <div className={`${styles.six_content} container `}>
        <Swiper
          modules={[Navigation, Pagination, Scrollbar, A11y]}
          spaceBetween={30}
          breakpoints={{
            600: {
              slidesPerView: 1,
            },
            800: {
              slidesPerView: 2,
            },
            1024: {
              slidesPerView: 3,
            },
          }}>
          <SwiperSlide>
            <div className={styles.swipe_content}>
              <div className={styles.six_image_holder}>
                <img src={photo1} width={150} height={150} alt="" className={styles.trainer} />
                <img src={photo3}  alt="" />
              </div>

              <div className={styles.six_text}>
                <h4>Arya</h4>
                <p>Athletics </p>
                <div className={styles.starts}>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                </div>
                <p>
                Excellent personal training. Trainers who really care and go above and beyond to help you achieve your goals. Small and private gym that feels more personal. Highly recommended!
                </p>
              </div>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className={styles.swipe_content}>
              <div className={styles.six_image_holder}>
                <img src={photo2}  width={150} height={150}  alt="" className={styles.trainer} />
                <img src={photo3} alt="" />
              </div>

              <div className={styles.six_text}>
                <h4>surya</h4>
                <p>Athletics </p>
                <div className={styles.starts}>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                </div>
                <p>
                The staff here is incredibly friendly and extremely qualified! They know how to push you to the limit in the best way possible with your workouts. You will not leave disappointed! Such a family vibe as soon as you walk in the doors – I highly recommend checking this gym out.
                </p>
              </div>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className={styles.swipe_content}>
              <div className={styles.six_image_holder}>
                <img src={photo4}  width={150} height={150}  alt="" className={styles.trainer} />
                <img src={photo3} alt="" />
              </div>

              <div className={styles.six_text}>
                <h4>tiger shroff</h4>
                <p>Athletics </p>
                <div className={styles.starts}>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                </div>
                <p>
                I love this place. I highly recommend this place to anyone who wants to get in shape. The trainers are really awesome and helpful, they make you feel really comfortable. The 45 min training goes super fast and you really enjoy doing it. Everyday is a new training, so it is never boring.
                </p>
              </div>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className={styles.swipe_content}>
              <div className={styles.six_image_holder}>
                <img src={photo5} width={150} height={150} alt="" className={styles.trainer} />
                <img src={photo3} alt="" />
              </div>

              <div className={styles.six_text}>
                <h4>vikram</h4>
                <p>Athletics </p>
                <div className={styles.starts}>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                </div>
                <p>
                This gym has the best energy, staff, and feel. Everything is so clean, every trainer closely watches and corrects everyone’s form, and a DJ on Saturday. Keep doing exactly what you are doing.


                </p>
              </div>
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
};

export default Sixth;
