import styles from "./home.module.css";

const Tenth = () => {
  return (
    <div className={`${styles.ten} container sections-padding`}>
      <h2>Articles & News</h2>
      <div data-aos="zoom-out-right">
        <span>March 23, 2022</span>
        <span>Fitness</span>
        <h3>The 10 best exercises to do in your park</h3>
        <p>Exercising in the park can be a refreshing and enjoyable way to stay fit and healthy. Here are ten of the best exercises you can do in a park
        </p>
        <button>Read More</button>
      </div>
      <div data-aos="zoom-out-right">
        <span>March 23, 2022</span>
        <span>Health</span>
        <h3>The 10 best exercises to do in your park</h3>
        <p>Remember to warm up before starting, stay hydrated, and listen to your body. Always use proper form to prevent injuries and maximize the benefits of your workout .
        </p>
        <button>Read More</button>
      </div>
      <div data-aos="zoom-out-right">
        <span>March 23, 2022</span>
        <span>Nutrition</span>
        <h3>The 10 best exercises to do in your park</h3>
        <p>Enjoy the fresh air and natural surroundings while you exercise in the park .
        </p>
        <button>Read More</button>
      </div>
    </div>
  );
};

export default Tenth;
