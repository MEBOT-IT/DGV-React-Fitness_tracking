import React from 'react';

const ProductList = () => {
    return (
        <div>
            <h1>product list page</h1>
        </div>
    );
};

export default ProductList;