import First from "./First";
import Second from "./Second";

const Schedule = () => {
  return (
    <div>
      <First />
      <Second />
    </div>
  );
};

export default Schedule;
