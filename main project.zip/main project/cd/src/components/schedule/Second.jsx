import styles from "./schedule.module.css";

const Second = () => {
  return (
    <div className={`${styles.second} container sections-padding`}>
      <div>
        <h1 className="paragraph">Classes Schedule</h1>
        <h2>Schedule Overview</h2>
        <br></br>
        <h3>For Age Category Below 20</h3>
      </div>
      <div className={styles.schedule}>
        <div className={styles.days}>
          <h5>Workouts</h5>
          <h5>Monday</h5>
          <h5>Tuesday</h5>
          <h5>Wednesday</h5>
          <h5>Thursday</h5>
          <h5>Friday</h5>
          <h5>Saturday</h5>
        </div>

        <div className={styles.colums}>
          <div>1</div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>2</div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>

        <div className={styles.colums}>
          <div>3</div>
          <div>
            <h4>Running</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Running</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Rest</h4>
          </div>
          <div>
            <h4>Running</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Running</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>4</div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>5</div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
      </div>
      <br />
      <h3>For Age Category 20 to 50 </h3>
      <div className={styles.schedule}>
        <div className={styles.days}>
          <h5>Workouts</h5>
          <h5>Monday</h5>
          <h5>Tuesday</h5>
          <h5>Wednesday</h5>
          <h5>Thursday</h5>
          <h5>Friday</h5>
          <h5>Saturday</h5>
        </div>

        <div className={styles.colums}>
          <div>1</div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>2</div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>

        <div className={styles.colums}>
          <div>3</div>
          <div>
            <h4>Agility Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Agility Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Rest</h4>
          </div>
          <div>
            <h4>Agility Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Agility Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>4</div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>5</div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
          <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div>
            <h4>CoolDown</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
      </div>
      <br />
      <h3>For Age Category 50 and Above</h3>

      <div className={styles.schedule}>
        <div className={styles.days}>
          <h5>Workouts</h5>
          <h5>Monday</h5>
          <h5>Tuesday</h5>
          <h5>Wednesday</h5>
          <h5>Thursday</h5>
          <h5>Friday</h5>
          <h5>Saturday</h5>
        </div>

        <div className={styles.colums}>
          <div>1</div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Stretching</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>2</div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Warmups</h4>
            <p> 10 - 15 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>

        <div className={styles.colums}>
          <div>3</div>
          <div>
            <h4>Cycling</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Cycling</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Cycling</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>4</div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Strength Training</h4>
            <p> 20 - 30 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
        <div className={styles.colums}>
          <div>5</div>
          <div>
            <h4>Yoga</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Yoga</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
          <div>
            <h4>Yoga</h4>
            <p> 15 - 20 mins</p>
            <p>Robert Cage</p>
          </div>
          <div><h4>Rest</h4></div>
        </div>
      </div>
    </div>

  );
};

export default Second;
