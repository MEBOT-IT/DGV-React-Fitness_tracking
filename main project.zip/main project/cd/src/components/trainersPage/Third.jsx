import styles from "./trainers.module.css";

const Third = () => {
  return (
    <div className={`${styles.third} container `}>
      <p className="paragraph">Welcome</p>
      <h2>Take a look at my routines</h2>
      <p>Workout routine offers several benefits that can positively impact your physical and mental well-being.
      </p>
    </div>
  );
};

export default Third;
